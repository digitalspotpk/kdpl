// ═══════════════════════════════════════════════════════════════
// KDPL GLOBAL STORE — Multi-tournament, localStorage + Firestore
// ═══════════════════════════════════════════════════════════════
//
// Data model: ALL tournaments/teams/players/venues/fixtures/live
// matches (across every Organizer) are synced in one shared Firestore
// doc, each entity tagged with a tournamentId. The store filters
// everything down to the ACTIVE tournament for the pages to consume,
// so existing pages (Teams, Players, Fixtures, Scorer, etc.) don't
// need to know multi-tournament exists — they just read
// state.teams / state.players / ... as before.
//
// Roles:
//  - hasSetupAccess (PIN, default 7254): unlocks ONLY the Firebase
//    bootstrap Settings page. Does NOT grant tournament management.
//  - Organizer: real Firebase Auth account (email/password, self
//    sign-up). Can manage ONLY the tournament(s) they created.
//  - Super Admin: Firebase Auth account whose email is in the
//    superAdminEmails allowlist. Can manage every tournament + users
//    + ads + app settings.
//  - isAdmin (used everywhere for edit-gating) = computed:
//    isSuperAdmin OR (signed-in organizer owns the active tournament)

import { useState, useEffect, useCallback } from 'react';
import { doc, onSnapshot, setDoc } from 'firebase/firestore';
import {
  onAuthStateChanged, signInWithEmailAndPassword,
  createUserWithEmailAndPassword, signOut,
} from 'firebase/auth';
import { db, auth } from '../firebase';
import type {
  AppState, Team, Player, Venue, Fixture, LiveMatch,
  Tournament, Notification, OrganizerProfile, UndoSnapshot,
  AdSlot, BallEvent, PlayerInningsStats, BowlerInningsStats
} from '../types';

const CLOUD_DOC = doc(db, 'kdpl', 'data');

function cloudSet(field: string, value: unknown): void {
  setDoc(CLOUD_DOC, { [field]: value }, { merge: true }).catch(e => console.warn('Cloud sync failed', e));
}

function ls<T>(key: string, fallback: T): T {
  try {
    const v = localStorage.getItem(key);
    return v ? JSON.parse(v) : fallback;
  } catch { return fallback; }
}

function lsSet(key: string, value: unknown): void {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) { console.warn('LS write failed', e); }
}

// djb2 hash — for the Setup Access PIN only
function hashPin(pin: string): string {
  let hash = 5381;
  for (let i = 0; i < 1024; i++) {
    for (let j = 0; j < pin.length; j++) {
      hash = ((hash << 5) + hash) ^ pin.charCodeAt(j);
      hash = hash & hash;
    }
  }
  return 'kdpl_' + Math.abs(hash).toString(16);
}

const DEFAULT_AD_SLOTS: AdSlot[] = [
  { id: 'ad1', name: 'Dashboard Top Banner', position: 'dashboard-top', adCode: '', enabled: false, createdAt: Date.now() },
  { id: 'ad2', name: 'Dashboard Mid Rectangle', position: 'dashboard-mid', adCode: '', enabled: false, createdAt: Date.now() },
  { id: 'ad3', name: 'Fixtures Top Banner', position: 'fixtures-top', adCode: '', enabled: false, createdAt: Date.now() },
  { id: 'ad4', name: 'Standings Top Banner', position: 'standings-top', adCode: '', enabled: false, createdAt: Date.now() },
  { id: 'ad5', name: 'Scorecard Bottom', position: 'scorecard-bottom', adCode: '', enabled: false, createdAt: Date.now() },
  { id: 'ad6', name: 'Live Sidebar', position: 'live-sidebar', adCode: '', enabled: false, createdAt: Date.now() },
];

// ── Internal state = AppState + the full unfiltered "all tournaments" data ──
interface RawStore {
  tournaments: Tournament[];
  activeTournamentId: string | null;
  organizers: OrganizerProfile[];
  allTeams: Team[];
  allPlayers: Player[];
  allVenues: Venue[];
  allFixtures: Fixture[];
  allLiveMatches: LiveMatch[];
  authUid: string | null;
  authEmail: string | null;
  superAdminEmails: string[];
  hasSetupAccess: boolean;
  pageHistory: string[];
}

interface InternalState extends AppState, RawStore {}

// Given the raw multi-tournament data, compute the per-active-tournament
// view (tournament/teams/players/venues/fixtures/liveMatch/isAdmin/isSuperAdmin).
function withDerived(s: InternalState): InternalState {
  const tournament = s.tournaments.find(t => t.id === s.activeTournamentId) || null;
  const isSuperAdmin = !!s.authEmail && s.superAdminEmails.map(e => e.toLowerCase()).includes(s.authEmail.toLowerCase());
  const organizerProfile = s.organizers.find(o => o.uid === s.authUid) || null;
  const isApprovedOrganizer = organizerProfile?.status === 'approved';
  const isOwner = !!tournament && !!s.authUid && tournament.organizerUid === s.authUid && isApprovedOrganizer;
  return {
    ...s,
    tournament,
    organizerProfile,
    teams: s.allTeams.filter(t => t.tournamentId === s.activeTournamentId),
    players: s.allPlayers.filter(p => p.tournamentId === s.activeTournamentId),
    venues: s.allVenues.filter(v => v.tournamentId === s.activeTournamentId),
    fixtures: s.allFixtures.filter(f => f.tournamentId === s.activeTournamentId),
    liveMatch: s.allLiveMatches.find(lm => lm.tournamentId === s.activeTournamentId) || null,
    isSuperAdmin,
    isAdmin: isSuperAdmin || isOwner,
  };
}

// Rolls this match's ball-by-ball performance into each player's career totals
// (runs, wickets, catches, etc. on the Player record) — without this, per-player
// stats pages stay empty even though the match itself was fully scored.
function applyPlayerStats(allPlayers: Player[], lm: LiveMatch): Player[] {
  const allBatting: Record<string, PlayerInningsStats> = { ...lm.innings1.playerStats, ...lm.innings2.playerStats };
  const allBowling: Record<string, BowlerInningsStats> = { ...lm.innings1.bowlerStats, ...lm.innings2.bowlerStats };
  const allBalls = [...lm.innings1.ballEvents, ...lm.innings2.ballEvents];

  const participantIds = new Set([
    ...Object.keys(allBatting), ...Object.keys(allBowling),
    ...allBalls.filter(b => b.isWicket && b.fielderId).map(b => b.fielderId),
  ]);

  return allPlayers.map(p => {
    if (!participantIds.has(p.id)) return p;
    const bat = allBatting[p.id];
    const bowl = allBowling[p.id];
    const catches = allBalls.filter(b => b.isWicket && b.fielderId === p.id && (b.wicketType === 'Caught' || b.wicketType === 'Run-Out')).length;
    const stumpings = allBalls.filter(b => b.isWicket && b.fielderId === p.id && b.wicketType === 'Stumped').length;

    const runsThisMatch = bat?.runs || 0;
    const wicketsThisMatch = bowl?.wickets || 0;
    const oversThisMatch = (bowl?.overs || 0) + (bowl?.balls || 0) / 6;

    return {
      ...p,
      matches: p.matches + 1,
      runs: p.runs + runsThisMatch,
      balls: p.balls + (bat?.balls || 0),
      fours: p.fours + (bat?.fours || 0),
      sixes: p.sixes + (bat?.sixes || 0),
      fifties: p.fifties + (runsThisMatch >= 50 && runsThisMatch < 100 ? 1 : 0),
      hundreds: p.hundreds + (runsThisMatch >= 100 ? 1 : 0),
      highScore: Math.max(p.highScore, runsThisMatch),
      wickets: p.wickets + wicketsThisMatch,
      oversBowled: Math.round((p.oversBowled + oversThisMatch) * 10) / 10,
      runsConceded: p.runsConceded + (bowl?.runs || 0),
      catches: p.catches + catches,
      stumpings: p.stumpings + stumpings,
      mvpScore: p.mvpScore + runsThisMatch + wicketsThisMatch * 20 + (catches + stumpings) * 10,
    };
  });
}

// Computes the match result, updates the underlying Fixture, and updates
// both teams' win/loss/points/NRR — called when the 2nd innings ends.
function finalizeMatch(s: InternalState, lm: LiveMatch): InternalState {
  const teamAId = lm.teamAId;
  const teamBId = lm.teamBId;
  const inns1 = lm.innings1; // whichever team batted first
  const inns2 = lm.innings2;
  const team1Batted = inns1.teamId; // team that batted 1st
  const team2Batted = inns2.teamId; // team that batted 2nd (chasing)

  let winnerId = '';
  let loserId = '';
  let margin = 'Match Tied';
  if (inns2.runs > inns1.runs) {
    winnerId = team2Batted; loserId = team1Batted;
    const wicketsLeft = Math.max(0, (s.allPlayers.filter(p => p.teamId === team2Batted && p.tournamentId === s.activeTournamentId).length || 11) - 1 - inns2.wickets);
    margin = `${wicketsLeft} wicket${wicketsLeft === 1 ? '' : 's'}`;
  } else if (inns1.runs > inns2.runs) {
    winnerId = team1Batted; loserId = team2Batted;
    margin = `${inns1.runs - inns2.runs} run${inns1.runs - inns2.runs === 1 ? '' : 's'}`;
  }

  const teamAScore = teamAId === team1Batted ? inns1.runs : inns2.runs;
  const teamBScore = teamAId === team1Batted ? inns2.runs : inns1.runs;
  const teamAOvers = teamAId === team1Batted ? `${inns1.overs}.${inns1.balls}` : `${inns2.overs}.${inns2.balls}`;
  const teamBOvers = teamAId === team1Batted ? `${inns2.overs}.${inns2.balls}` : `${inns1.overs}.${inns1.balls}`;

  // Man of the match — highest run scorer across both innings (simple heuristic)
  const allBatters = [...Object.entries(inns1.playerStats), ...Object.entries(inns2.playerStats)];
  const mom = allBatters.sort((a, b) => b[1].runs - a[1].runs)[0];
  const momPlayer = mom ? s.allPlayers.find(p => p.id === mom[0]) : undefined;

  const allFixtures = s.allFixtures.map(f => f.id === lm.fixtureId ? {
    ...f,
    status: 'completed' as const,
    result: {
      winnerId, loserTeamId: loserId, teamAScore, teamBScore, teamAOvers, teamBOvers,
      margin, manOfMatch: momPlayer?.name || '',
    },
  } : f);

  const allTeams = s.allTeams.map(t => {
    if (t.id !== teamAId && t.id !== teamBId) return t;
    const isWinner = t.id === winnerId;
    const isTie = !winnerId;
    const runsFor = t.id === team1Batted ? inns1.runs : inns2.runs;
    const runsAgainst = t.id === team1Batted ? inns2.runs : inns1.runs;
    const oversFor = t.id === team1Batted ? inns1.overs + inns1.balls / 6 : inns2.overs + inns2.balls / 6;
    const oversAgainst = t.id === team1Batted ? inns2.overs + inns2.balls / 6 : inns1.overs + inns1.balls / 6;
    const nrrDelta = (runsFor / (oversFor || 1)) - (runsAgainst / (oversAgainst || 1));
    return {
      ...t,
      matchesPlayed: t.matchesPlayed + 1,
      wins: t.wins + (isWinner ? 1 : 0),
      losses: t.losses + (!isTie && !isWinner ? 1 : 0),
      ties: t.ties + (isTie ? 1 : 0),
      points: t.points + (isWinner ? 2 : isTie ? 1 : 0),
      nrr: Math.round((t.nrr + nrrDelta) * 100) / 100,
    };
  });

  const allLiveMatches = [...s.allLiveMatches.filter(x => x.id !== lm.id), lm];
  const allPlayers = applyPlayerStats(s.allPlayers, lm);

  lsSet('kdpl_all_fixtures', allFixtures);
  lsSet('kdpl_all_teams', allTeams);
  lsSet('kdpl_all_live_matches', allLiveMatches);
  lsSet('kdpl_all_players', allPlayers);
  cloudSet('allFixtures', allFixtures);
  cloudSet('allTeams', allTeams);
  cloudSet('allLiveMatches', allLiveMatches);
  cloudSet('allPlayers', allPlayers);

  return withDerived({ ...s, allFixtures, allTeams, allLiveMatches, allPlayers });
}

export function useKDPLStore() {
  const [state, setState] = useState<InternalState>(() => withDerived({
    currentPage: 'dashboard',
    pageHistory: [],
    currentTab: 'home',
    isAdmin: false,
    isSuperAdmin: false,
    hasSetupAccess: ls('kdpl_has_setup_access', false),
    authUid: null,
    authEmail: null,
    userRole: 'GUEST',
    user: null,
    tournaments: ls('kdpl_tournaments', []),
    activeTournamentId: ls('kdpl_active_tournament_id', null),
    organizers: ls('kdpl_organizers', []),
    organizerProfile: null,
    tournament: null,
    allTeams: ls('kdpl_all_teams', []),
    allPlayers: ls('kdpl_all_players', []),
    allVenues: ls('kdpl_all_venues', []),
    allFixtures: ls('kdpl_all_fixtures', []),
    allLiveMatches: ls('kdpl_all_live_matches', []),
    teams: [], players: [], venues: [], fixtures: [], liveMatch: null,
    notifications: ls('kdpl_notifications', []),
    adSlots: ls('kdpl_ad_slots', DEFAULT_AD_SLOTS),
    supportWhatsapp: ls('kdpl_support_whatsapp', '923065772734'),
    superAdminEmails: ls('kdpl_super_admin_emails', []),
    theme: ls('kdpl_theme', 'dark'),
    lang: ls('kdpl_lang', 'en'),
    isOnline: navigator.onLine,
    syncStatus: 'synced',
    writeQueue: 0,
  }));

  // Track signed-in Firebase Auth user (Organizer or Super Admin — role decided by allowlist)
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, user => {
      setState(s => withDerived({ ...s, authUid: user?.uid || null, authEmail: user?.email || null }));
    }, () => { /* auth not configured yet — app keeps working for guests/PIN */ });
    return () => unsub();
  }, []);

  // online/offline tracking
  useEffect(() => {
    const handleOnline = () => setState(s => ({ ...s, isOnline: true, syncStatus: 'synced' }));
    const handleOffline = () => setState(s => ({ ...s, isOnline: false, syncStatus: 'offline' }));
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => { window.removeEventListener('online', handleOnline); window.removeEventListener('offline', handleOffline); };
  }, []);

  // Cloud sync — real-time updates from Firestore so every device/organizer sees the same data
  useEffect(() => {
    const unsub = onSnapshot(CLOUD_DOC, (snap) => {
      if (!snap.exists()) return;
      const data = snap.data() as Record<string, unknown>;
      setState(s => {
        const next = { ...s };
        if (data.tournaments !== undefined) { next.tournaments = data.tournaments as Tournament[]; lsSet('kdpl_tournaments', data.tournaments); }
        if (data.organizers !== undefined) { next.organizers = data.organizers as OrganizerProfile[]; lsSet('kdpl_organizers', data.organizers); }
        if (data.allTeams !== undefined) { next.allTeams = data.allTeams as Team[]; lsSet('kdpl_all_teams', data.allTeams); }
        if (data.allPlayers !== undefined) { next.allPlayers = data.allPlayers as Player[]; lsSet('kdpl_all_players', data.allPlayers); }
        if (data.allVenues !== undefined) { next.allVenues = data.allVenues as Venue[]; lsSet('kdpl_all_venues', data.allVenues); }
        if (data.allFixtures !== undefined) { next.allFixtures = data.allFixtures as Fixture[]; lsSet('kdpl_all_fixtures', data.allFixtures); }
        if (data.allLiveMatches !== undefined) { next.allLiveMatches = data.allLiveMatches as LiveMatch[]; lsSet('kdpl_all_live_matches', data.allLiveMatches); }
        if (data.notifications !== undefined) { next.notifications = data.notifications as Notification[]; lsSet('kdpl_notifications', data.notifications); }
        if (data.adSlots !== undefined) { next.adSlots = data.adSlots as AdSlot[]; lsSet('kdpl_ad_slots', data.adSlots); }
        if (data.superAdminEmails !== undefined) { next.superAdminEmails = data.superAdminEmails as string[]; lsSet('kdpl_super_admin_emails', data.superAdminEmails); }
        if (data.supportWhatsapp !== undefined) { next.supportWhatsapp = data.supportWhatsapp as string; lsSet('kdpl_support_whatsapp', data.supportWhatsapp); }
        else { cloudSet('supportWhatsapp', s.supportWhatsapp); } // first run — push default number to cloud once
        next.syncStatus = 'synced';
        return withDerived(next);
      });
    }, (error) => {
      console.warn('Cloud sync unavailable (check src/firebase.ts config & Firestore rules):', error.message);
    });
    return () => unsub();
  }, []);

  const navigate = useCallback((page: string) => {
    setState(s => {
      if (page === s.currentPage) return s;
      const pageHistory = [...s.pageHistory, s.currentPage].slice(-30);
      return { ...s, currentPage: page, pageHistory };
    });
    window.scrollTo(0, 0);
  }, []);

  const goBack = useCallback(() => {
    setState(s => {
      if (s.pageHistory.length === 0) return { ...s, currentPage: 'dashboard' };
      const pageHistory = [...s.pageHistory];
      const prev = pageHistory.pop()!;
      return { ...s, currentPage: prev, pageHistory };
    });
    window.scrollTo(0, 0);
  }, []);

  const setTheme = useCallback((theme: 'dark' | 'light') => {
    lsSet('kdpl_theme', theme);
    setState(s => ({ ...s, theme }));
  }, []);

  const setLang = useCallback((lang: 'en' | 'ur') => {
    lsSet('kdpl_lang', lang);
    setState(s => ({ ...s, lang }));
  }, []);

  // ── Setup Access (PIN) — bootstraps Firebase config ONLY ──────────
  const loginAdmin = useCallback((pin: string): boolean => {
    const stored = ls('kdpl_admin_pin', hashPin('7254'));
    if (hashPin(pin) === stored) {
      lsSet('kdpl_has_setup_access', true);
      setState(s => withDerived({ ...s, hasSetupAccess: true }));
      return true;
    }
    return false;
  }, []);

  const changePin = useCallback((newPin: string) => {
    lsSet('kdpl_admin_pin', hashPin(newPin));
  }, []);

  // ── Organizer / Super Admin auth (real Firebase Auth accounts) ────
  const organizerSignUp = useCallback(async (name: string, email: string, password: string): Promise<string | null> => {
    try {
      const cred = await createUserWithEmailAndPassword(auth, email, password);
      setState(s => {
        const newProfile: OrganizerProfile = {
          uid: cred.user.uid,
          email: cred.user.email || email,
          name,
          status: 'pending',
          createdAt: Date.now(),
        };
        const organizers = [...s.organizers, newProfile];
        lsSet('kdpl_organizers', organizers);
        cloudSet('organizers', organizers);
        return withDerived({ ...s, organizers });
      });
      return null;
    } catch (e: any) {
      if (e?.code === 'auth/email-already-in-use') return 'This email is already registered — try Sign In instead.';
      if (e?.code === 'auth/weak-password') return 'Password must be at least 6 characters.';
      if (e?.code === 'auth/invalid-email') return 'Email format is invalid.';
      if (e?.code === 'auth/configuration-not-found') return "Email/Password sign-in method isn't enabled in the Firebase Console.";
      if (e?.code === 'auth/api-key-not-valid' || e?.code === 'auth/invalid-api-key') return 'Firebase config is incorrect — check it again in Settings.';
      if (e?.code === 'auth/network-request-failed') return 'Check your internet connection.';
      return `Signup failed: ${e?.code || e?.message || 'unknown error'}`;
    }
  }, []);

  const organizerLogin = useCallback(async (email: string, password: string): Promise<string | null> => {
    try {
      await signInWithEmailAndPassword(auth, email, password);
      return null;
    } catch (e: any) {
      if (e?.code === 'auth/invalid-credential' || e?.code === 'auth/wrong-password' || e?.code === 'auth/user-not-found') return 'Incorrect email or password.';
      if (e?.code === 'auth/too-many-requests') return 'Too many attempts — please try again later.';
      if (e?.code === 'auth/configuration-not-found') return "Email/Password sign-in method isn't enabled in the Firebase Console.";
      if (e?.code === 'auth/api-key-not-valid' || e?.code === 'auth/invalid-api-key') return 'Firebase config is incorrect — check it again in Settings.';
      if (e?.code === 'auth/network-request-failed') return 'Check your internet connection.';
      if (e?.code === 'auth/user-disabled') return 'This account has been disabled.';
      return `Login failed: ${e?.code || e?.message || 'unknown error'}`;
    }
  }, []);

  const logoutAdmin = useCallback(() => {
    lsSet('kdpl_has_setup_access', false);
    signOut(auth).catch(() => {});
    setState(s => withDerived({ ...s, hasSetupAccess: false, authUid: null, authEmail: null }));
  }, []);

  const addSuperAdminEmail = useCallback((email: string) => {
    setState(s => {
      const superAdminEmails = Array.from(new Set([...s.superAdminEmails, email.trim().toLowerCase()]));
      lsSet('kdpl_super_admin_emails', superAdminEmails);
      cloudSet('superAdminEmails', superAdminEmails);
      return withDerived({ ...s, superAdminEmails });
    });
  }, []);

  const removeSuperAdminEmail = useCallback((email: string) => {
    setState(s => {
      const superAdminEmails = s.superAdminEmails.filter(e => e.toLowerCase() !== email.toLowerCase());
      lsSet('kdpl_super_admin_emails', superAdminEmails);
      cloudSet('superAdminEmails', superAdminEmails);
      return withDerived({ ...s, superAdminEmails });
    });
  }, []);

  // ── Organizer approval (Super Admin only — enforced in the UI) ────
  const approveOrganizer = useCallback((uid: string) => {
    setState(s => {
      const organizers = s.organizers.map(o => o.uid === uid ? { ...o, status: 'approved' as const } : o);
      lsSet('kdpl_organizers', organizers);
      cloudSet('organizers', organizers);
      return withDerived({ ...s, organizers });
    });
  }, []);

  const rejectOrganizer = useCallback((uid: string) => {
    setState(s => {
      const organizers = s.organizers.map(o => o.uid === uid ? { ...o, status: 'rejected' as const } : o);
      lsSet('kdpl_organizers', organizers);
      cloudSet('organizers', organizers);
      return withDerived({ ...s, organizers });
    });
  }, []);

  const removeOrganizer = useCallback((uid: string) => {
    setState(s => {
      const organizers = s.organizers.filter(o => o.uid !== uid);
      lsSet('kdpl_organizers', organizers);
      cloudSet('organizers', organizers);
      return withDerived({ ...s, organizers });
    });
  }, []);

  // ── Tournaments (multi-tournament) ─────────────────────────────────
  const switchTournament = useCallback((id: string | null) => {
    lsSet('kdpl_active_tournament_id', id);
    setState(s => withDerived({ ...s, activeTournamentId: id }));
  }, []);

  const createTournament = useCallback((data: Omit<Tournament, 'id' | 'organizerUid' | 'organizerEmail' | 'createdAt'>) => {
    setState(s => {
      const newTournament: Tournament = {
        ...data,
        id: `t${Date.now()}`,
        organizerUid: s.authUid || '',
        organizerEmail: s.authEmail || '',
        createdAt: Date.now(),
      };
      const tournaments = [...s.tournaments, newTournament];
      lsSet('kdpl_tournaments', tournaments);
      cloudSet('tournaments', tournaments);
      lsSet('kdpl_active_tournament_id', newTournament.id);
      return withDerived({ ...s, tournaments, activeTournamentId: newTournament.id });
    });
  }, []);

  const updateTournament = useCallback((tournament: Tournament) => {
    setState(s => {
      const tournaments = s.tournaments.map(t => t.id === tournament.id ? tournament : t);
      lsSet('kdpl_tournaments', tournaments);
      cloudSet('tournaments', tournaments);
      return withDerived({ ...s, tournaments });
    });
  }, []);

  const deleteTournament = useCallback((id: string) => {
    setState(s => {
      const tournaments = s.tournaments.filter(t => t.id !== id);
      const activeTournamentId = s.activeTournamentId === id ? null : s.activeTournamentId;
      lsSet('kdpl_tournaments', tournaments);
      cloudSet('tournaments', tournaments);
      lsSet('kdpl_active_tournament_id', activeTournamentId);
      return withDerived({ ...s, tournaments, activeTournamentId });
    });
  }, []);

  // ── Teams (tagged to active tournament) ────────────────────────────
  const addTeam = useCallback((team: Omit<Team, 'tournamentId'> & { tournamentId?: string }) => {
    setState(s => {
      const allTeams = [...s.allTeams, { ...team, tournamentId: s.activeTournamentId || '' }];
      lsSet('kdpl_all_teams', allTeams);
      cloudSet('allTeams', allTeams);
      return withDerived({ ...s, allTeams });
    });
  }, []);

  const updateTeam = useCallback((team: Team) => {
    setState(s => {
      const allTeams = s.allTeams.map(t => t.id === team.id ? team : t);
      lsSet('kdpl_all_teams', allTeams);
      cloudSet('allTeams', allTeams);
      return withDerived({ ...s, allTeams });
    });
  }, []);

  const deleteTeam = useCallback((id: string) => {
    setState(s => {
      const allTeams = s.allTeams.filter(t => t.id !== id);
      lsSet('kdpl_all_teams', allTeams);
      cloudSet('allTeams', allTeams);
      return withDerived({ ...s, allTeams });
    });
  }, []);

  // ── Players ─────────────────────────────────────────────────────────
  const addPlayer = useCallback((player: Omit<Player, 'tournamentId'> & { tournamentId?: string }) => {
    setState(s => {
      const allPlayers = [...s.allPlayers, { ...player, tournamentId: s.activeTournamentId || '' }];
      lsSet('kdpl_all_players', allPlayers);
      cloudSet('allPlayers', allPlayers);
      return withDerived({ ...s, allPlayers });
    });
  }, []);

  const updatePlayer = useCallback((player: Player) => {
    setState(s => {
      const allPlayers = s.allPlayers.map(p => p.id === player.id ? player : p);
      lsSet('kdpl_all_players', allPlayers);
      cloudSet('allPlayers', allPlayers);
      return withDerived({ ...s, allPlayers });
    });
  }, []);

  const deletePlayer = useCallback((id: string) => {
    setState(s => {
      const allPlayers = s.allPlayers.filter(p => p.id !== id);
      lsSet('kdpl_all_players', allPlayers);
      cloudSet('allPlayers', allPlayers);
      return withDerived({ ...s, allPlayers });
    });
  }, []);

  const banPlayer = useCallback((id: string, reason: string) => {
    setState(s => {
      const allPlayers = s.allPlayers.map(p => p.id === id ? { ...p, banned: true, banReason: reason } : p);
      lsSet('kdpl_all_players', allPlayers);
      cloudSet('allPlayers', allPlayers);
      return withDerived({ ...s, allPlayers });
    });
  }, []);

  const unbanPlayer = useCallback((id: string) => {
    setState(s => {
      const allPlayers = s.allPlayers.map(p => p.id === id ? { ...p, banned: false, banReason: '' } : p);
      lsSet('kdpl_all_players', allPlayers);
      cloudSet('allPlayers', allPlayers);
      return withDerived({ ...s, allPlayers });
    });
  }, []);

  // ── Venues ──────────────────────────────────────────────────────────
  const addVenue = useCallback((venue: Omit<Venue, 'tournamentId'> & { tournamentId?: string }) => {
    setState(s => {
      const allVenues = [...s.allVenues, { ...venue, tournamentId: s.activeTournamentId || '' }];
      lsSet('kdpl_all_venues', allVenues);
      cloudSet('allVenues', allVenues);
      return withDerived({ ...s, allVenues });
    });
  }, []);

  const updateVenue = useCallback((venue: Venue) => {
    setState(s => {
      const allVenues = s.allVenues.map(v => v.id === venue.id ? venue : v);
      lsSet('kdpl_all_venues', allVenues);
      cloudSet('allVenues', allVenues);
      return withDerived({ ...s, allVenues });
    });
  }, []);

  const deleteVenue = useCallback((id: string) => {
    setState(s => {
      const allVenues = s.allVenues.filter(v => v.id !== id);
      lsSet('kdpl_all_venues', allVenues);
      cloudSet('allVenues', allVenues);
      return withDerived({ ...s, allVenues });
    });
  }, []);

  // ── Fixtures ────────────────────────────────────────────────────────
  const addFixture = useCallback((fixture: Fixture) => {
    setState(s => {
      const allFixtures = [...s.allFixtures, { ...fixture, tournamentId: s.activeTournamentId || '' }];
      lsSet('kdpl_all_fixtures', allFixtures);
      cloudSet('allFixtures', allFixtures);
      return withDerived({ ...s, allFixtures });
    });
  }, []);

  const updateFixture = useCallback((fixture: Fixture) => {
    setState(s => {
      const allFixtures = s.allFixtures.map(f => f.id === fixture.id ? fixture : f);
      lsSet('kdpl_all_fixtures', allFixtures);
      cloudSet('allFixtures', allFixtures);
      return withDerived({ ...s, allFixtures });
    });
  }, []);

  const deleteFixture = useCallback((id: string) => {
    setState(s => {
      const allFixtures = s.allFixtures.filter(f => f.id !== id);
      // A deleted fixture's live match (if any) becomes stale — remove it too,
      // otherwise the Live page keeps showing scores for a match that no longer exists.
      const allLiveMatches = s.allLiveMatches.filter(lm => lm.fixtureId !== id);
      lsSet('kdpl_all_fixtures', allFixtures);
      lsSet('kdpl_all_live_matches', allLiveMatches);
      cloudSet('allFixtures', allFixtures);
      cloudSet('allLiveMatches', allLiveMatches);
      return withDerived({ ...s, allFixtures, allLiveMatches });
    });
  }, []);

  // Manually clear the current live match (e.g. started scoring by mistake) —
  // without touching the fixture itself, which goes back to 'scheduled'.
  const clearLiveMatch = useCallback(() => {
    setState(s => {
      const current = s.allLiveMatches.find(lm => lm.tournamentId === s.activeTournamentId);
      if (!current) return s;
      const allLiveMatches = s.allLiveMatches.filter(lm => lm.id !== current.id);
      const allFixtures = s.allFixtures.map(f => f.id === current.fixtureId ? { ...f, status: 'scheduled' as const } : f);
      lsSet('kdpl_all_live_matches', allLiveMatches);
      lsSet('kdpl_all_fixtures', allFixtures);
      cloudSet('allLiveMatches', allLiveMatches);
      cloudSet('allFixtures', allFixtures);
      return withDerived({ ...s, allLiveMatches, allFixtures });
    });
  }, []);

  // A team didn't show up — award the win to the other team without playing.
  // No NRR change (no runs were actually scored), but the result still counts
  // toward matches played / points, same as a real result.
  const awardWalkover = useCallback((fixtureId: string, winnerId: string) => {
    setState(s => {
      const fixture = s.allFixtures.find(f => f.id === fixtureId);
      if (!fixture) return s;
      const loserId = fixture.teamAId === winnerId ? fixture.teamBId : fixture.teamAId;

      const allFixtures = s.allFixtures.map(f => f.id === fixtureId ? {
        ...f,
        status: 'completed' as const,
        result: {
          winnerId, loserTeamId: loserId,
          teamAScore: 0, teamBScore: 0, teamAOvers: '0.0', teamBOvers: '0.0',
          margin: 'Walkover', manOfMatch: '',
        },
      } : f);

      const allTeams = s.allTeams.map(t => {
        if (t.id !== winnerId && t.id !== loserId) return t;
        const isWinner = t.id === winnerId;
        return {
          ...t,
          matchesPlayed: t.matchesPlayed + 1,
          wins: t.wins + (isWinner ? 1 : 0),
          losses: t.losses + (isWinner ? 0 : 1),
          points: t.points + (isWinner ? 2 : 0),
        };
      });

      lsSet('kdpl_all_fixtures', allFixtures);
      lsSet('kdpl_all_teams', allTeams);
      cloudSet('allFixtures', allFixtures);
      cloudSet('allTeams', allTeams);
      return withDerived({ ...s, allFixtures, allTeams });
    });
  }, []);

  // Cancel a scheduled match (e.g. rained out) — no winner, no stats impact.
  const cancelFixture = useCallback((fixtureId: string) => {
    setState(s => {
      const allFixtures = s.allFixtures.map(f => f.id === fixtureId ? { ...f, status: 'abandoned' as const } : f);
      lsSet('kdpl_all_fixtures', allFixtures);
      cloudSet('allFixtures', allFixtures);
      return withDerived({ ...s, allFixtures });
    });
  }, []);

  // ── Live match (tagged to active tournament) ───────────────────────
  const updateLiveMatch = useCallback((liveMatch: (Omit<LiveMatch, 'tournamentId'> & { tournamentId?: string }) | null) => {
    setState(s => {
      const withoutCurrent = s.allLiveMatches.filter(lm => lm.tournamentId !== s.activeTournamentId);
      const allLiveMatches = liveMatch
        ? [...withoutCurrent, { ...liveMatch, tournamentId: s.activeTournamentId || '' }]
        : withoutCurrent;
      lsSet('kdpl_all_live_matches', allLiveMatches);
      cloudSet('allLiveMatches', allLiveMatches);
      return withDerived({ ...s, allLiveMatches });
    });
  }, []);

  // ── Notifications ───────────────────────────────────────────────────
  const addNotification = useCallback((notif: Notification) => {
    setState(s => {
      const notifications = [notif, ...s.notifications].slice(0, 50);
      lsSet('kdpl_notifications', notifications);
      cloudSet('notifications', notifications);
      return { ...s, notifications };
    });
  }, []);

  const markNotifRead = useCallback((id: string) => {
    setState(s => {
      const notifications = s.notifications.map(n => n.id === id ? { ...n, read: true } : n);
      lsSet('kdpl_notifications', notifications);
      cloudSet('notifications', notifications);
      return { ...s, notifications };
    });
  }, []);

  const markAllRead = useCallback(() => {
    setState(s => {
      const notifications = s.notifications.map(n => ({ ...n, read: true }));
      lsSet('kdpl_notifications', notifications);
      cloudSet('notifications', notifications);
      return { ...s, notifications };
    });
  }, []);

  const clearNotifications = useCallback(() => {
    lsSet('kdpl_notifications', []);
    cloudSet('notifications', []);
    setState(s => ({ ...s, notifications: [] }));
  }, []);

  const updateSupportWhatsapp = useCallback((number: string) => {
    lsSet('kdpl_support_whatsapp', number);
    cloudSet('supportWhatsapp', number);
    setState(s => ({ ...s, supportWhatsapp: number }));
  }, []);

  const updateAdSlot = useCallback((slot: AdSlot) => {
    setState(s => {
      const adSlots = s.adSlots.map(a => a.id === slot.id ? slot : a);
      lsSet('kdpl_ad_slots', adSlots);
      cloudSet('adSlots', adSlots);
      return { ...s, adSlots };
    });
  }, []);

  const generateFixtures = useCallback(() => {
    // Berger round-robin pairings, then greedily packed into days:
    // max 3 matches per day total, max 2 matches per team per day
    // (lets a team play twice in a day, and finishes the tournament faster).
    setState(s => {
      const teams = s.allTeams.filter(t => t.tournamentId === s.activeTournamentId);
      const n = teams.length;
      if (n < 2) return s;

      const arr = n % 2 === 0 ? teams.map(t => t.id) : [...teams.map(t => t.id), 'BYE'];
      const totalTeams = arr.length;
      const totalRounds = totalTeams - 1;
      const matchesPerRound = totalTeams / 2;
      const venueIds = s.allVenues.filter(v => v.tournamentId === s.activeTournamentId).map(v => v.id);
      const tournament = s.tournaments.find(t => t.id === s.activeTournamentId);

      // Step 1 — generate round-robin pairings (order = preferred scheduling priority)
      const pairings: { round: number; teamAId: string; teamBId: string }[] = [];
      for (let round = 0; round < totalRounds; round++) {
        for (let match = 0; match < matchesPerRound; match++) {
          const home = arr[match];
          const away = arr[totalTeams - 1 - match];
          if (home !== 'BYE' && away !== 'BYE') {
            pairings.push({ round: round + 1, teamAId: home, teamBId: away });
          }
        }
        const last = arr.pop()!;
        arr.splice(1, 0, last);
      }

      // Step 2 — greedily pack pairings into days (max 3 matches/day, max 2/team/day)
      const MAX_MATCHES_PER_DAY = 3;
      const MAX_MATCHES_PER_TEAM_PER_DAY = 2;
      const days: { matches: number; teamsPlayed: Record<string, number> }[] = [];

      const assignDay = (teamA: string, teamB: string): number => {
        for (let i = 0; i < days.length; i++) {
          const d = days[i];
          if (d.matches < MAX_MATCHES_PER_DAY &&
              (d.teamsPlayed[teamA] || 0) < MAX_MATCHES_PER_TEAM_PER_DAY &&
              (d.teamsPlayed[teamB] || 0) < MAX_MATCHES_PER_TEAM_PER_DAY) {
            d.matches++;
            d.teamsPlayed[teamA] = (d.teamsPlayed[teamA] || 0) + 1;
            d.teamsPlayed[teamB] = (d.teamsPlayed[teamB] || 0) + 1;
            return i;
          }
        }
        days.push({ matches: 1, teamsPlayed: { [teamA]: 1, [teamB]: 1 } });
        return days.length - 1;
      };

      const TIME_SLOTS: { time: string; slot: 'Day' | 'Night' }[] = [
        { time: '10:00', slot: 'Day' },
        { time: '14:30', slot: 'Day' },
        { time: '18:00', slot: 'Night' },
      ];

      const startDate = new Date(tournament?.startDate || new Date().toISOString().slice(0, 10));
      let matchNum = 1;
      const generated: Fixture[] = pairings.map(p => {
        const dayIndex = assignDay(p.teamAId, p.teamBId);
        const positionInDay = days[dayIndex].matches; // 1-based, since incremented before returning
        const date = new Date(startDate);
        date.setDate(date.getDate() + dayIndex);
        const venueId = venueIds[(matchNum - 1) % (venueIds.length || 1)] || '';
        const { time, slot } = TIME_SLOTS[Math.min(positionInDay, 3) - 1];
        return {
          id: `gen-f${matchNum}`,
          tournamentId: s.activeTournamentId || '',
          round: p.round,
          stage: 'group' as const,
          matchNumber: matchNum++,
          teamAId: p.teamAId,
          teamBId: p.teamBId,
          venueId,
          date: date.toISOString().slice(0, 10),
          time,
          slot,
          status: 'scheduled',
          umpires: [],
          overs: tournament?.overs || 10,
          createdAt: Date.now(),
        };
      });

      // Step 3 — auto-generate the knockout stage (Quarter/Semi/Final) based on
      // team count. Teams are TBD placeholders — the organizer assigns the
      // actual qualifiers once the group stage standings are known.
      const groupDaysUsed = days.length;
      const knockoutRounds: { stage: Fixture['stage']; matches: number }[] = [];
      if (n >= 8) knockoutRounds.push({ stage: 'quarter-final', matches: 4 }, { stage: 'semi-final', matches: 2 }, { stage: 'final', matches: 1 });
      else if (n >= 4) knockoutRounds.push({ stage: 'semi-final', matches: 2 }, { stage: 'final', matches: 1 });
      else if (n >= 2) knockoutRounds.push({ stage: 'final', matches: 1 });

      let dayOffset = groupDaysUsed;
      let koRound = totalRounds + 1;
      knockoutRounds.forEach(({ stage, matches }) => {
        for (let i = 0; i < matches; i++) {
          const dayIndex = dayOffset + Math.floor(i / MAX_MATCHES_PER_DAY);
          const positionInDay = i % MAX_MATCHES_PER_DAY;
          const date = new Date(startDate);
          date.setDate(date.getDate() + dayIndex);
          const label = matches > 1 ? `${i + 1}` : '';
          generated.push({
            id: `gen-f${matchNum}`,
            tournamentId: s.activeTournamentId || '',
            round: koRound,
            stage,
            matchNumber: matchNum++,
            teamAId: `TBD-${stage}-${label}A`,
            teamBId: `TBD-${stage}-${label}B`,
            venueId: venueIds[0] || '',
            date: date.toISOString().slice(0, 10),
            time: TIME_SLOTS[positionInDay].time,
            slot: TIME_SLOTS[positionInDay].slot,
            status: 'scheduled',
            umpires: [],
            overs: tournament?.overs || 10,
            createdAt: Date.now(),
          });
        }
        dayOffset += Math.ceil(matches / MAX_MATCHES_PER_DAY);
        koRound++;
      });

      const allFixtures = [...s.allFixtures.filter(f => f.tournamentId !== s.activeTournamentId), ...generated];
      lsSet('kdpl_all_fixtures', allFixtures);
      cloudSet('allFixtures', allFixtures);
      return withDerived({ ...s, allFixtures });
    });
  }, []);

  const shufflePlayers = useCallback(() => {
    setState(s => {
      const teams = s.allTeams.filter(t => t.tournamentId === s.activeTournamentId);
      const players = s.allPlayers.filter(p => p.tournamentId === s.activeTournamentId);
      if (teams.length === 0) return s;
      const batsmen = players.filter(p => p.role === 'Batsman');
      const allRounders = players.filter(p => p.role === 'All-Rounder');
      const bowlers = players.filter(p => p.role === 'Bowler');
      const wks = players.filter(p => p.role === 'Wicket-Keeper');

      const fisherYates = <T,>(arr: T[]): T[] => {
        const a = [...arr];
        for (let i = a.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [a[i], a[j]] = [a[j], a[i]];
        }
        return a;
      };

      const shuffled = [...fisherYates(batsmen), ...fisherYates(allRounders), ...fisherYates(bowlers), ...fisherYates(wks)];
      const teamCount = teams.length;

      const updatedIds = new Map<string, string>();
      shuffled.forEach((player, i) => updatedIds.set(player.id, teams[i % teamCount].id));

      const allPlayers = s.allPlayers.map(p => updatedIds.has(p.id) ? { ...p, teamId: updatedIds.get(p.id)! } : p);
      lsSet('kdpl_all_players', allPlayers);
      cloudSet('allPlayers', allPlayers);
      return withDerived({ ...s, allPlayers });
    });
  }, []);

  const recordBall = useCallback((ball: BallEvent) => {
    setState(s => {
      const current = s.allLiveMatches.find(lm => lm.tournamentId === s.activeTournamentId);
      if (!current) return s;
      const lm = { ...current };
      const innings = lm.currentInnings === 1 ? { ...lm.innings1 } : { ...lm.innings2 };

      // Snapshot pre-ball state so undo can restore batters/bowler exactly, not just numbers.
      const snapshot: UndoSnapshot = {
        ball,
        innings: lm.currentInnings,
        prevBatter1: innings.currentBatter1,
        prevBatter2: innings.currentBatter2,
        prevBowler: innings.currentBowler,
        prevLastOverBowlerId: lm.lastOverBowlerId || '',
      };

      innings.runs += ball.runs + ball.extras;
      innings.extras += ball.extras;

      let overJustCompleted = false;
      if (ball.extraType !== 'Wide' && ball.extraType !== 'No-Ball') {
        innings.balls += 1;
        if (innings.balls === 6) { innings.overs += 1; innings.balls = 0; overJustCompleted = true; }
      }

      if (innings.playerStats[ball.batsmanId]) {
        const bs = { ...innings.playerStats[ball.batsmanId] };
        bs.runs += ball.runs;
        if (ball.extraType === '') bs.balls += 1;
        if (ball.runs === 4) bs.fours += 1;
        if (ball.runs === 6) bs.sixes += 1;
        bs.strikeRate = bs.balls > 0 ? (bs.runs / bs.balls) * 100 : 0;
        if (ball.isWicket) { bs.isOut = true; bs.wicketType = ball.wicketType; bs.bowlerId = ball.bowlerId; bs.fielderId = ball.fielderId; }
        innings.playerStats = { ...innings.playerStats, [ball.batsmanId]: bs };
      }

      if (innings.bowlerStats[ball.bowlerId]) {
        const bwl = { ...innings.bowlerStats[ball.bowlerId] };
        bwl.runs += ball.runs + ball.extras;
        if (ball.extraType !== 'Wide' && ball.extraType !== 'No-Ball') {
          bwl.balls += 1;
          if (bwl.balls === 6) { bwl.overs += 1; bwl.balls = 0; }
        }
        if (ball.isWicket && ball.wicketType !== 'Run-Out') bwl.wickets += 1;
        bwl.economy = bwl.overs > 0 ? bwl.runs / bwl.overs : 0;
        innings.bowlerStats = { ...innings.bowlerStats, [ball.bowlerId]: bwl };
      }

      if (ball.isWicket) innings.wickets += 1;
      innings.ballEvents = [...innings.ballEvents, ball];
      lm.undoStack = [...(lm.undoStack || []).slice(-20), snapshot];

      // ── Strike rotation on odd runs (byes/leg-byes count; wides don't) ──
      const runsRun = (ball.extraType === 'Bye' || ball.extraType === 'Leg-Bye') ? ball.extras : ball.runs;
      if (ball.extraType !== 'Wide' && runsRun % 2 === 1) {
        const tmp = innings.currentBatter1;
        innings.currentBatter1 = innings.currentBatter2;
        innings.currentBatter2 = tmp;
      }

      // ── Wicket: the batter who's out must be replaced before the next ball ──
      if (ball.isWicket) {
        innings.currentBatter1 = '';
      }

      // ── Over complete: ends change (batters swap) + a new bowler is required ──
      if (overJustCompleted) {
        lm.lastOverBowlerId = ball.bowlerId;
        const tmp = innings.currentBatter1;
        innings.currentBatter1 = innings.currentBatter2;
        innings.currentBatter2 = tmp;
        innings.currentBowler = '';
      }

      if (lm.currentInnings === 1) lm.innings1 = innings;
      else lm.innings2 = innings;
      lm.updatedAt = Date.now();

      // ── Check whether the innings (or match) has ended ──
      const battingTeamPlayerCount = s.allPlayers.filter(p => p.teamId === innings.teamId && p.tournamentId === s.activeTournamentId).length || 11;
      const allOut = innings.wickets >= battingTeamPlayerCount - 1;
      const oversComplete = innings.overs >= lm.overs;
      const chaseComplete = lm.currentInnings === 2 && innings.runs > lm.innings1.runs;

      if (allOut || oversComplete || chaseComplete) {
        if (lm.currentInnings === 1) {
          lm.currentInnings = 2;
          lm.innings2 = { ...lm.innings2, target: innings.runs + 1 };
          lm.lastOverBowlerId = '';
        } else {
          lm.status = 'completed';
          const allLiveMatches = [...s.allLiveMatches.filter(x => x.tournamentId !== s.activeTournamentId), lm];
          return finalizeMatch({ ...s, allLiveMatches }, lm);
        }
      }

      const allLiveMatches = [...s.allLiveMatches.filter(x => x.tournamentId !== s.activeTournamentId), lm];
      lsSet('kdpl_all_live_matches', allLiveMatches);
      cloudSet('allLiveMatches', allLiveMatches);
      return withDerived({ ...s, allLiveMatches });
    });
  }, []);

  // Set the opening striker, non-striker and bowler — used to start each innings
  const selectOpeners = useCallback((strikerId: string, nonStrikerId: string, bowlerId: string) => {
    setState(s => {
      const current = s.allLiveMatches.find(lm => lm.tournamentId === s.activeTournamentId);
      if (!current) return s;
      const lm = { ...current };
      const innings = lm.currentInnings === 1 ? { ...lm.innings1 } : { ...lm.innings2 };
      innings.currentBatter1 = strikerId;
      innings.currentBatter2 = nonStrikerId;
      innings.currentBowler = bowlerId;
      innings.playerStats = {
        ...innings.playerStats,
        [strikerId]: innings.playerStats[strikerId] || { runs: 0, balls: 0, fours: 0, sixes: 0, isOut: false, wicketType: '', bowlerId: '', fielderId: '', strikeRate: 0 },
        [nonStrikerId]: innings.playerStats[nonStrikerId] || { runs: 0, balls: 0, fours: 0, sixes: 0, isOut: false, wicketType: '', bowlerId: '', fielderId: '', strikeRate: 0 },
      };
      innings.bowlerStats = {
        ...innings.bowlerStats,
        [bowlerId]: innings.bowlerStats[bowlerId] || { overs: 0, balls: 0, runs: 0, wickets: 0, maidens: 0, economy: 0 },
      };
      if (lm.currentInnings === 1) lm.innings1 = innings; else lm.innings2 = innings;
      lm.updatedAt = Date.now();
      const allLiveMatches = [...s.allLiveMatches.filter(x => x.tournamentId !== s.activeTournamentId), lm];
      lsSet('kdpl_all_live_matches', allLiveMatches);
      cloudSet('allLiveMatches', allLiveMatches);
      return withDerived({ ...s, allLiveMatches });
    });
  }, []);

  // Replace the dismissed batter (always the striker's slot) with a new batter
  const selectNextBatter = useCallback((batterId: string) => {
    setState(s => {
      const current = s.allLiveMatches.find(lm => lm.tournamentId === s.activeTournamentId);
      if (!current) return s;
      const lm = { ...current };
      const innings = lm.currentInnings === 1 ? { ...lm.innings1 } : { ...lm.innings2 };
      innings.currentBatter1 = batterId;
      innings.playerStats = {
        ...innings.playerStats,
        [batterId]: innings.playerStats[batterId] || { runs: 0, balls: 0, fours: 0, sixes: 0, isOut: false, wicketType: '', bowlerId: '', fielderId: '', strikeRate: 0 },
      };
      if (lm.currentInnings === 1) lm.innings1 = innings; else lm.innings2 = innings;
      lm.updatedAt = Date.now();
      const allLiveMatches = [...s.allLiveMatches.filter(x => x.tournamentId !== s.activeTournamentId), lm];
      lsSet('kdpl_all_live_matches', allLiveMatches);
      cloudSet('allLiveMatches', allLiveMatches);
      return withDerived({ ...s, allLiveMatches });
    });
  }, []);

  // Set the bowler for the next over (can't be the same bowler who just bowled)
  const selectNextBowler = useCallback((bowlerId: string) => {
    setState(s => {
      const current = s.allLiveMatches.find(lm => lm.tournamentId === s.activeTournamentId);
      if (!current) return s;
      const lm = { ...current };
      const innings = lm.currentInnings === 1 ? { ...lm.innings1 } : { ...lm.innings2 };
      innings.currentBowler = bowlerId;
      innings.bowlerStats = {
        ...innings.bowlerStats,
        [bowlerId]: innings.bowlerStats[bowlerId] || { overs: 0, balls: 0, runs: 0, wickets: 0, maidens: 0, economy: 0 },
      };
      if (lm.currentInnings === 1) lm.innings1 = innings; else lm.innings2 = innings;
      lm.updatedAt = Date.now();
      const allLiveMatches = [...s.allLiveMatches.filter(x => x.tournamentId !== s.activeTournamentId), lm];
      lsSet('kdpl_all_live_matches', allLiveMatches);
      cloudSet('allLiveMatches', allLiveMatches);
      return withDerived({ ...s, allLiveMatches });
    });
  }, []);

  // Organizer override — end the current innings early (e.g. declaration)
  const endInningsManually = useCallback(() => {
    setState(s => {
      const current = s.allLiveMatches.find(lm => lm.tournamentId === s.activeTournamentId);
      if (!current) return s;
      const lm = { ...current };
      if (lm.currentInnings === 1) {
        lm.currentInnings = 2;
        lm.innings2 = { ...lm.innings2, target: lm.innings1.runs + 1 };
        lm.lastOverBowlerId = '';
        lm.updatedAt = Date.now();
        const allLiveMatches = [...s.allLiveMatches.filter(x => x.tournamentId !== s.activeTournamentId), lm];
        lsSet('kdpl_all_live_matches', allLiveMatches);
        cloudSet('allLiveMatches', allLiveMatches);
        return withDerived({ ...s, allLiveMatches });
      } else {
        lm.status = 'completed';
        const allLiveMatches = [...s.allLiveMatches.filter(x => x.tournamentId !== s.activeTournamentId), lm];
        return finalizeMatch({ ...s, allLiveMatches }, lm);
      }
    });
  }, []);

  // Organizer override — end the match right now (abandon / force result)
  const endMatchManually = useCallback(() => {
    setState(s => {
      const current = s.allLiveMatches.find(lm => lm.tournamentId === s.activeTournamentId);
      if (!current) return s;
      const lm = { ...current, status: 'completed' as const };
      const allLiveMatches = [...s.allLiveMatches.filter(x => x.tournamentId !== s.activeTournamentId), lm];
      return finalizeMatch({ ...s, allLiveMatches }, lm);
    });
  }, []);

  const undoBall = useCallback(() => {
    setState(s => {
      const current = s.allLiveMatches.find(lm => lm.tournamentId === s.activeTournamentId);
      if (!current || !current.undoStack?.length) return s;
      const lm = { ...current };
      const undoStack = [...lm.undoStack];
      const snap = undoStack.pop();
      if (!snap) return s;
      lm.undoStack = undoStack;
      const last = snap.ball;

      // If the match had already completed and this ball ended it, reopen it.
      if (lm.status === 'completed') lm.status = 'live';
      lm.currentInnings = snap.innings;

      const innings = snap.innings === 1 ? { ...lm.innings1 } : { ...lm.innings2 };
      innings.runs = Math.max(0, innings.runs - last.runs - last.extras);
      innings.extras = Math.max(0, innings.extras - last.extras);
      if (last.extraType !== 'Wide' && last.extraType !== 'No-Ball') {
        if (innings.balls === 0 && innings.overs > 0) { innings.overs -= 1; innings.balls = 5; }
        else innings.balls = Math.max(0, innings.balls - 1);
      }
      if (last.isWicket) innings.wickets = Math.max(0, innings.wickets - 1);
      innings.ballEvents = innings.ballEvents.slice(0, -1);

      // Reverse batter stats
      if (innings.playerStats[last.batsmanId]) {
        const bs = { ...innings.playerStats[last.batsmanId] };
        bs.runs = Math.max(0, bs.runs - last.runs);
        if (last.extraType === '') bs.balls = Math.max(0, bs.balls - 1);
        if (last.runs === 4) bs.fours = Math.max(0, bs.fours - 1);
        if (last.runs === 6) bs.sixes = Math.max(0, bs.sixes - 1);
        bs.strikeRate = bs.balls > 0 ? (bs.runs / bs.balls) * 100 : 0;
        if (last.isWicket) { bs.isOut = false; bs.wicketType = ''; bs.bowlerId = ''; bs.fielderId = ''; }
        innings.playerStats = { ...innings.playerStats, [last.batsmanId]: bs };
      }
      // Reverse bowler stats
      if (innings.bowlerStats[last.bowlerId]) {
        const bwl = { ...innings.bowlerStats[last.bowlerId] };
        bwl.runs = Math.max(0, bwl.runs - last.runs - last.extras);
        if (last.extraType !== 'Wide' && last.extraType !== 'No-Ball') {
          if (bwl.balls === 0 && bwl.overs > 0) { bwl.overs -= 1; bwl.balls = 5; }
          else bwl.balls = Math.max(0, bwl.balls - 1);
        }
        if (last.isWicket && last.wicketType !== 'Run-Out') bwl.wickets = Math.max(0, bwl.wickets - 1);
        bwl.economy = bwl.overs > 0 ? bwl.runs / bwl.overs : 0;
        innings.bowlerStats = { ...innings.bowlerStats, [last.bowlerId]: bwl };
      }

      // Restore exactly who was batting/bowling before this ball
      innings.currentBatter1 = snap.prevBatter1;
      innings.currentBatter2 = snap.prevBatter2;
      innings.currentBowler = snap.prevBowler;
      lm.lastOverBowlerId = snap.prevLastOverBowlerId;

      if (snap.innings === 1) lm.innings1 = innings;
      else lm.innings2 = innings;
      lm.updatedAt = Date.now();

      const allLiveMatches = [...s.allLiveMatches.filter(x => x.tournamentId !== s.activeTournamentId), lm];
      lsSet('kdpl_all_live_matches', allLiveMatches);
      cloudSet('allLiveMatches', allLiveMatches);
      return withDerived({ ...s, allLiveMatches });
    });
  }, []);

  return {
    state,
    navigate,
    goBack,
    setTheme,
    setLang,
    loginAdmin,
    logoutAdmin,
    changePin,
    organizerSignUp,
    organizerLogin,
    addSuperAdminEmail,
    removeSuperAdminEmail,
    approveOrganizer,
    rejectOrganizer,
    removeOrganizer,
    switchTournament,
    createTournament,
    updateTournament,
    deleteTournament,
    addTeam,
    updateTeam,
    deleteTeam,
    addPlayer,
    updatePlayer,
    deletePlayer,
    banPlayer,
    unbanPlayer,
    addVenue,
    updateVenue,
    deleteVenue,
    addFixture,
    updateFixture,
    deleteFixture,
    awardWalkover,
    cancelFixture,
    updateLiveMatch,
    clearLiveMatch,
    addNotification,
    markNotifRead,
    markAllRead,
    clearNotifications,
    updateAdSlot,
    updateSupportWhatsapp,
    generateFixtures,
    shufflePlayers,
    recordBall,
    undoBall,
    selectOpeners,
    selectNextBatter,
    selectNextBowler,
    endInningsManually,
    endMatchManually,
  };
}

export type KDPLStore = ReturnType<typeof useKDPLStore>;
