// ═══════════════════════════════════════════════════════════════
// FIREBASE CONFIG — Cloud sync (Firestore) + Super Admin login (Auth)
// ═══════════════════════════════════════════════════════════════
//
// 👉 PASTE YOUR FIREBASE PROJECT CONFIG HERE 👈
//
// Where to find it:
// 1. Go to https://console.firebase.google.com, open your project
//    (e.g. "kd-premier-league")
// 2. Top-left gear icon (⚙️) → "Project settings"
// 3. Scroll down to the "Your apps" section
//    - If no Web app (</>) is registered yet, click the "</>" icon
//      → give the app a name → "Register app"
// 4. An object will appear under "SDK setup and configuration" like
//    the one below — paste those exact values below.
//
// (Alternative: this config can also be pasted from inside the app via
//  the Super Admin's "Firebase Settings" page — no code editing needed.)

const DEFAULT_CONFIG = {
  apiKey: "AIzaSyCevZQ147HjQKzEyQjr7cfFgI4Icj-tlYM",
  authDomain: "kd-premier-league.firebaseapp.com",
  projectId: "kd-premier-league",
  storageBucket: "kd-premier-league.firebasestorage.app",
  messagingSenderId: "568383052969",
  appId: "1:568383052969:web:5d659048366e3bcb5b9db8",
};

import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

// Runtime override: if Super Admin saved a config via the in-app
// "Firebase Settings" page, use that instead of the hardcoded one above.
function loadConfig() {
  try {
    const saved = localStorage.getItem('kdpl_firebase_config');
    if (saved) return JSON.parse(saved);
  } catch { /* ignore malformed saved config */ }
  return DEFAULT_CONFIG;
}

export const firebaseConfig = loadConfig();
export const firebaseApp = initializeApp(firebaseConfig);
export const db = getFirestore(firebaseApp);
export const auth = getAuth(firebaseApp);

export function isFirebaseConfigured(): boolean {
  return firebaseConfig.apiKey !== "YOUR_API_KEY" && !!firebaseConfig.apiKey;
}

