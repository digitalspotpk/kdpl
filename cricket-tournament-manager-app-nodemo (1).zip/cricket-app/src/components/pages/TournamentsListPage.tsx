// ═══════════════════════════════════════════════════════════════
// KDPL TOURNAMENTS LIST — Public directory of every tournament
// Tapping a tournament opens its own dashboard (teams/matches/etc).
// ═══════════════════════════════════════════════════════════════

import { TrophyIcon, UsersIcon, CalendarIcon, ChevronRightIcon, PlusIcon } from '../ui/Icons';
import type { KDPLStore } from '../../store/useKDPLStore';

export default function TournamentsListPage({ store }: { store: KDPLStore }) {
  const { state, switchTournament, navigate } = store;
  const { tournaments, allTeams, allFixtures, authUid } = state;

  const openTournament = (id: string) => {
    switchTournament(id);
    navigate('dashboard');
  };

  const statusPill = (status: string) =>
    status === 'active' ? 'bg-green-500/15 text-green-400 border-green-500/30'
    : status === 'completed' ? 'bg-kdpl-border text-kdpl-muted border-kdpl-border'
    : 'bg-blue-500/15 text-blue-400 border-blue-500/30';

  return (
    <div className="flex flex-col gap-4 p-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-kdpl-text font-oswald font-bold text-xl flex items-center gap-2">
            <TrophyIcon size={20} className="text-kdpl-neon" /> All Tournaments
          </h2>
          <p className="text-kdpl-muted text-xs">Open any tournament to see its full record</p>
        </div>
      </div>

      <button onClick={() => navigate(authUid ? 'create-tournament' : 'organizer-auth')}
        className="flex items-center justify-center gap-2 py-3.5 rounded-2xl bg-kdpl-neon text-kdpl-darker font-oswald font-bold text-sm shadow-lg shadow-kdpl-neon/20">
        <PlusIcon size={16} /> {authUid ? 'Create New Tournament' : 'Become an Organizer to Create a Tournament'}
      </button>

      {tournaments.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center gap-2">
          <div className="text-4xl mb-1">🏏</div>
          <h3 className="text-kdpl-text font-oswald font-bold">No Tournaments Yet</h3>
          <p className="text-kdpl-muted text-sm max-w-xs">Be the first to create a tournament!</p>
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {tournaments.map((t) => {
            const teamCount = allTeams.filter((tm) => tm.tournamentId === t.id).length;
            const fixtureCount = allFixtures.filter((f) => f.tournamentId === t.id).length;
            return (
              <button key={t.id} onClick={() => openTournament(t.id)}
                className="flex items-center gap-3 rounded-2xl bg-kdpl-card border border-kdpl-border p-4 text-left active:scale-[0.99] transition-all">
                <div className="w-12 h-12 rounded-xl bg-kdpl-neon/10 border border-kdpl-neon/30 flex items-center justify-center flex-shrink-0 text-xl">
                  🏆
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-kdpl-text font-oswald font-bold text-sm truncate">{t.name}</span>
                    <span className={`text-[9px] px-1.5 py-0.5 rounded-full border capitalize flex-shrink-0 ${statusPill(t.status)}`}>{t.status}</span>
                  </div>
                  <div className="flex items-center gap-3 mt-1 text-kdpl-muted text-[11px]">
                    <span className="flex items-center gap-1"><UsersIcon size={11} /> {teamCount} teams</span>
                    <span className="flex items-center gap-1"><CalendarIcon size={11} /> {fixtureCount} matches</span>
                  </div>
                  {t.organizer && <div className="text-kdpl-muted text-[10px] mt-0.5">by {t.organizer}</div>}
                </div>
                <ChevronRightIcon size={18} className="text-kdpl-muted flex-shrink-0" />
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
